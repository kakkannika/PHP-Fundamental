<?php

// Assigiment Operator 

    $x =5;
    $x+=5;
    echo $x;
    echo "\n";

    $y=10;
    $y+=4;
    echo $y;
    echo "\n";

    $y-=4;
    echo $y;

    echo "\n";
    $y*=2;
    echo $y;

    echo "\n";

    $y/=10;
    echo $y;

  echo "\n";
    $y=10;
    $z=20;
    echo ($y + $z);
    echo "\n";
    echo($y-$z);
    echo "\n";

    


?>