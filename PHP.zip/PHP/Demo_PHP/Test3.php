
<?php

$casesensitive = "I am unique . \n";
$Casesensitive ="I'm different ";
echo $casesensitive;
echo $Casesensitive;



?>


