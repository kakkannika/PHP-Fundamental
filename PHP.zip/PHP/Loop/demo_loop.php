<?php

// Loop : repeat of the condition that true , then it's stop 
// for loop 
// do while loop 
// while loop

$i=0;
while($i<=5){
    echo "Diplay Number : $i\n";
   // $i++;
   $i=$i+2;

    // i++ : not check conditon , but i increse to 1
    //++i : show result recently ; 


}

?>