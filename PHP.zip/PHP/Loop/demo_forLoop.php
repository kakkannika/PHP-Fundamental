<?php


/*for($i=10;$i>=0; $i--){
    echo "Number : $i\n";

}
*/
$i=5;
while($i>=0){
    echo "Number : $i\n";
    $i--;

}
?>