<?php
$secretNumber = 50;
$guessed = false;

echo "Welcome to the Guess the Number game!\n";
echo "Try to guess the secret number between 1 and 100.\n";

while (!$guessed) {
   $guess = (int)readline("Enter your guess: ");

   if ($guess == $secretNumber) {
       $guessed = true;
       echo "Congratulations! You guessed the number $secretNumber \n";
   } else if ($guess < $secretNumber) {
       echo "Try a higher number.\n";
   } else {
       echo "Try a lower number.\n";
   }
}

?>