<?php


$i=0;
while($i<=5){
    switch($i){
        case 1:
            echo "$i\n";
            break;
        case 2 : 
            echo "$i\n";
            break;
        default: 
        echo "I love Cambodia ";
    }
    $i++;
}


?>