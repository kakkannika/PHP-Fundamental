<?php
$message = "Hello World";
echo $message;
?>