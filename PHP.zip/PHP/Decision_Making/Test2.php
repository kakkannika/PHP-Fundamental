<?php

$total = 100; 
$specific_value =200;

$percentage =($specific_value /$total)*100;
echo $percentage;


?>