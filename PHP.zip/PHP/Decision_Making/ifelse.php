<?php

$age = 25; 
if($age<=18){
    echo "You are an adult.";
}else if($age>=30){
    echo "You are not yet an adult ";

}else if($age<10){
    echo " She is very cute ";
}
else{
    echo "I am a young ";
}
?>