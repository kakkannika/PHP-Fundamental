<?php


$person = [
    'name' => 'John',
    'age' => 30,
    'city' => 'New York'
];

foreach($person as $p => $value) {
 // echo "Key=" . $p . ", Value=" . $value;
 echo "$p: $value\n";
  echo "\n";
}
// => : roll that we need to use it.





?>
