<?php
$persons = [
    0 => [
        'name' => 'John',
        'age' => 30,
        'city' => 'New York',
        'childrens' => ['child1', 'child2']
    ],
    1 => [
        'name' => 'Bo',
        'age' => 30,
        'city' => 'Cambodia',
        'childrens' => ['child1', 'child2']
    ]
];

foreach ($persons as $person) {
    echo "-------------------- \n";
   foreach($person as $key => $value) {
    if($key == 'childrens') {
        $childs = "";
        foreach($value as $val) {
foreach ($persons as $person) {
    echo "-------------------- \n";
   foreach($person as $key => $value) {
    if($key == 'childrens') {
        $childs = "";
        foreach($value as $val) {
            $childs = "$childs , $val";
        }
        echo "$key: $childs \n";
    } else {
        echo "$key: $value \n";
    }
   }
}
        }
    }
}
}

?>
